'use strict';

module.exports = function(companyPromotionsCount) {

};
