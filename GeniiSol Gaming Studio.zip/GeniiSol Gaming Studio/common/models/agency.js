'use strict';
// var randomNumber = require('random-number');
module.exports = function (Agency) {
};
