'use strict';

module.exports = function (AddManagement) {
  AddManagement.AdInfoManagement = async function (gameid, adId) 
  {
    let obj=new AddManagement();
     obj.fromGame=gameid;
     obj.AdId=adId;
    let responce=await AddManagement.create(obj)
     return responce;
  }
  AddManagement.GetAdInfoManagement = async function (agencyId) 
  {
    //@import Module
    let Game=AddManagement.app.models.Game;
    let Ad=AddManagement.app.models.Ad;
    //@Fetch Ads against agency
    let adsMangmentInfo=await Game.find({
      where:{agencyId:agencyId},
      fields:{deviceId:false,created:false,updated:false,agencyId:false},
      include:{
        relation:"Ads",
        scope:{
          fields:['id','count','status','name'],
          include:{
            relation:"AddManagements",
            scope:{
              fields:['fromGame','id']
            }
          }
        }
      }
    })

      let ArrayObj=new Array();
      let obj=new Object();    
      let stringdata=JSON.stringify(adsMangmentInfo);
      let ads =JSON.parse(stringdata);
      
      ads.forEach(element => 
        {
            element.Ads.forEach(innerElemnt=>
                  {   
                        let temp = {}
                        let data=innerElemnt.AddManagements;
                        obj.name=innerElemnt.name;
                        obj.totalCount=data.length;
                        console.log(data);
                         for (let i=0;i<data.length;i++)
                              {

                                  if(temp[data.fromGame])
                                  {
                                    temp[data.fromGame]++
                                  }
                                  else
                                  {
                                    temp[data.fromGame]=1
                                  }
                              } 
                          obj.game=temp;
                        
                 })             
      });
    return ArrayObj; 
  }
  
}
