'use strict';

module.exports = function(Device) {

};
