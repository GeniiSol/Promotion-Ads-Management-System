"use strict";
let rn = require("random-number");
let AWS = require("aws-sdk");
module.exports = function(Ad) {
  //testing comment
  //@---------------------------- Here For Android-------------------------------
  Ad.showRandomAdd = async function(gameId, platform) {
    //@Importing other Model
    let agencyCount = Ad.app.models.agencyAdCount;
    let game = Ad.app.models.Game;
    let gstatus = await game.find({ where: { id: gameId } });
    console.log(gstatus)
    let gameCtg = gstatus[0].category;
    console.log(gameCtg);
    if (gstatus[0].status == "OFF") {
      return {
        gameUrl: null,
        type: null,
        category: null,
        adUrl: null,
        title: null
      };
    }
    //calcultae agency percentage
    //agency percentage related variables
    let adId;
    let isNeedToUpdate = false;
    let agency = await game.find({ where: { id: gameId } });
    if (agency.length == 0) {
      return "gameId is not exist";
    } else {
      if (agency[0].agencyId == "18") {
        //soft circles
        adId = 18;
        console.log("softcircles");
      } //any other agency
      else {
        //Fetch all agencies
        console.log("agency");
        let total = 0;
        let agencyIds = new Array();
        let defaultPercentage = new Array();
        let calculatedPercentage = new Array();
        let agencyCountInstance = await agencyCount.find();
        //calculate total
        for (let index = 0; index < agencyCountInstance.length; index++) {
          total = total + agencyCountInstance[index].count;
        }
        //calculate percentage for each agency
        for (let index = 0; index < agencyCountInstance.length; index++) {
          let percentage = Math.trunc(
            (agencyCountInstance[index].count / total) * 100
          );
          agencyIds.push(agencyCountInstance[index].agencyId);
          defaultPercentage.push(agencyCountInstance[index].percentage);
          calculatedPercentage.push(percentage);
        }
        //Choose the agency Id
        for (let index = 0; index < agencyCountInstance.length; index++) {
          if (defaultPercentage[index] >= calculatedPercentage[index]) {
            isNeedToUpdate = true;
            adId = agencyIds[index];
            break;
          }
        }
      }

      //Fetch agency ads based on id
      let agencyAds = await Ad.find({
        where: { agencyId: adId }
      });
      if (agencyAds.length == 0) {
        return "no ad for agency";
      } else {
        //Applay Filter for Android or IOS
        let androidAds = new Array();
        let IOSAds = new Array();
        let range;
        let ad;
        let adObj = new Object();
        //For Android
        if (platform == "Android") {
          for (let index = 0; index < agencyAds.length; index++) {
            let status = agencyAds[index].status;
            let id = agencyAds[index].gameId;
            let gameInstance = await game.find({ where: { id: id } });
            if (gameInstance.length != 0) {
              if (
                gameInstance[0].deviceId == "1" ||
                gameInstance[0].deviceId == "3"
              ) {
                if (gameCtg == "Both" || gameCtg == agencyAds[index].category) {
                  if (id == gameId || status == "OFF") {
                  } //ignore the game that is belonging to current game
                  else {
                    console.log("-------------------");
                    androidAds.push(agencyAds[index]);
                  }
                }
              }
            }
          }

          //Random ad for android
          if (androidAds.length == 0) {
            return "no ad for android ";
          } else {
            range = androidAds.length - 1;
            let randomId = Math.floor(Math.random() * (range - 0 + 1)) + 0;
            ad = androidAds[randomId];
          }
        }
        //For IOS
        else if (platform == "IOS") {
          for (let index = 0; index < agencyAds.length; index++) {
            let status = agencyAds[index].status;
            let id = agencyAds[index].gameId;
            let gameInstance = await game.find({ where: { id: id } });
            if (gameInstance.length != 0) {
              if (
                gameInstance[0].deviceId == 2 ||
                gameInstance[0].deviceId == 3
              ) {
                if (
                  gameInstance[0].category == "Both" ||
                  gameInstance[0].category == agencyAds[index].category
                ) {
                  if (id == gameId || status == "OFF") {
                  } //ignore the game that is belonging to current game
                  else {
                    IOSAds.push(agencyAds[index]);
                  }
                }
              }
            }
          }

          //Random ad for ios
          if (IOSAds.length == 0) {
            return "no ad for IOS";
          } else {
            range = IOSAds.length - 1;
            let randomId = Math.floor(Math.random() * (range - 0 + 1)) + 0;
            ad = IOSAds[randomId];
          }
        } else return "Platform not exist";
        if (isNeedToUpdate) {
          //adcount
          let adCount = ad.count;
          adCount++;
          Ad.update({ id: ad.id }, { count: adCount });
          //agency count
          let obj = await agencyCount.find({ where: { agencyId: adId } });
          let agenCount = obj[0].count;
          agenCount++;
          agencyCount.update({ agencyId: adId }, { count: agenCount });
        }

        //Preparing ad object
        let randomGameId = ad.gameId;
        let randomGame = await game.find({ where: { id: randomGameId } });

        // Arqam has added this to avoid the error. This will show hardcoded raw type of agency 18.

        if (platform == "Android") {
          adObj.gameUrl = randomGame[0].androidUrl;
        } else {
          adObj.gameUrl = randomGame[0].iosUrl;
        }
        adObj.type = ad.type;

        adObj.category = ad.category;
        let name = ad.url;
        //Genrate S3 url
        AWS.config.update({
          accessKeyId: "AKIAVJUN23QMKIS6JJNE",
          secretAccessKey: "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",
          region: "ap-northeast-2"
        });

        // Generate Object Against this configuration
        const s3 = new AWS.S3();
        let params = {
          Bucket: "crosspromo-s3bucket",
          Key: name,
          Expires: 100 * 60 * 60
        };
        adObj.adUrl = s3.getSignedUrl("getObject", params);
        adObj.title = randomGame[0].name;
        return adObj;
      }
    }
  };
  //@---------------------------- Here for pagination-------------------------------
  Ad.pagination = async function(start, limit, gameId) {
    let paginationData = new Array();
    let data = await Ad.find({ where: { gameId: gameId } });
    data.reverse();
    if (data.length != 0) {
      for (
        let index = start;
        limit != 0 && data.length > index;
        index++, limit--
      ) {
        paginationData.push(data[index]);
      }
    } else {
      paginationData = null;
    }

    return paginationData;
  };
  //@---------------------------- Here for Add against agency-------------------------
  Ad.AddsForGame = async function(gameId) {
    let data = await Ad.find({ where: { gameId: gameId } });
    return data;
  };
  //@---------------------------- Here for Status chaing-------------------------
  Ad.Status = async function(adId, status) {
    let res = await Ad.update({ id: adId }, { status: status });
    return res;
  };
  //@------------------------------Update Ad--------------------------------
  Ad.UpdateAd = function(id, data, cb) {
    Ad.updateAll(
      { id: id },
      { name: data.name, category: data.category },
      function(err, res) {
        cb(null, res);
      }
    );
  };
};
