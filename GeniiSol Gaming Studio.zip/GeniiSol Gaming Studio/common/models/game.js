"use strict";

module.exports = function(Game) {
  Game.remoteMethod("AgencyId", {
    accepts: { arg: "id", type: "number", required: true },
    http: { path: "/:id/agency_id", verb: "get" },
    returns: { arg: "Games", type: "Object" }
  });
  Game.AgencyId = function(id, cb) {
    Game.find({ where: { agencyId: id } }, function(err, obj) {
      cb(null, obj);
    });
  };

  Game.pagination = async function(start, limit, agencyId) {
    let paginationData = new Array();
    let data = await Game.find({ where: { agencyId: agencyId } });
    data.reverse();
    if (data.length != 0) {
      for (
        let index = start;
        limit != 0 && data.length > index;
        index++, limit--
      ) {
        paginationData.push(data[index]);
      }
    } else {
      paginationData = null;
    }
    return paginationData;
  };
  Game.updateGame = function(id, data, cb) {
    Game.updateAll(
      { id: id },
      {
        name: data.name,
        androidUrl: data.androidUrl,
        iosUrl: data.iosUrl,
        category: data.category,
        deviceId: data.deviceId
      },
      function(err, res) {
        cb(null, res);
      }
    );
  };
  //----------------------status
  Game.status = function(id, status, cb) {
    Game.updateAll(
      { id: id },
      {
        status: status.status
      },
      function(err, res) {
        cb(null, res);
      }
    );
  };
};
