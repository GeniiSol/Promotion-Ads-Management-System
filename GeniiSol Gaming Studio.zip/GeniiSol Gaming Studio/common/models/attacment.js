'use strict';

module.exports = function(Attacment) {

};
