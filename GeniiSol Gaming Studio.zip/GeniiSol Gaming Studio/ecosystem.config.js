module.exports = {
    apps: [
     {
      name: "my-app",
      script: "./bin/www",
      env: {
       PORT: 3000,
       NODE_ENV: "production"
      }
     }
    ],
    deploy: {
     production: {
      user: "xyz",
      host: "xyz.com",
      key: "xyz.pem",
      ref: "origin/master",
      repo: "xyz.git",
      path: "/home/ubuntu/my-app",
      "post-deploy":
       "npm install && pm2 startOrRestart ecosystem.config.js"
     }
    }
   };